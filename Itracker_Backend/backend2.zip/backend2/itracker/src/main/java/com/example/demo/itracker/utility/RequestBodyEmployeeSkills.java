package com.example.demo.itracker.utility;

public class RequestBodyEmployeeSkills {
	
	 private int skillId;
	 private String employeeId;
	public int getSkillId() {
		return skillId;
	}
	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	 
}
