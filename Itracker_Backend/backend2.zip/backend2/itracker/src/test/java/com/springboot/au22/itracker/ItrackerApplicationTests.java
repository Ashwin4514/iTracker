package com.springboot.au22.itracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
